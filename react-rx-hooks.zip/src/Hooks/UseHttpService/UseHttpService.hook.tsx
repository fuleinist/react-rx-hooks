/*!
 * @license
 * Copyright Foxtel Pty Ltd. All Rights Reserved.
 */

import { useState, useEffect } from 'react';
import { Observable, Subscription } from 'rxjs';
import { tap, map } from 'rxjs/operators';

import { HttpRxAdapter } from '../../Services/Http/Adapter/Rx/HttpRx.adapter';
import { HttpService } from '../../Services/Http/Http.service';

type AJAX_OBJ = {
  url: string,
  label: string,
  body: Object,
}

/**
 * useHttpService Hook to utilize HttpService in React.SFC
 *
 * @export
 * @param {AJAX_OBJ} ajax object for `useHttpService` to be used.
 * @param {Object} defaultData default data object for useHttpService.
 * @param {Function} loading callback function for useHttpService.
 * @param {Function} success callback function for useHttpService.
 * @param {Function} failed callback function for useHttpService.
 * @returns {[Object, Function]} updated data object and AjaxPost function
 */

export const useHttpService = (ajax: AJAX_OBJ, defaultData: Object, loading: Function, success: Function, failed: Function): [Object, Function] => {
  const [data, updateData] = useState(defaultData);
  const httpRxAdapter = new HttpRxAdapter();
  const onAjaxPost =
    (ajax: AJAX_OBJ, loading: Function, success: Function, failed: Function): Observable<Object> => {
        loading();
        const httpService = new HttpService({ httpAdapter: httpRxAdapter });
        const obRx$ = httpService
          .post(ajax.url, {
            body: { ...ajax.body },
            headers: {
              [`Content-Type`]: `application/json`,
            },
            // timeout is 3 minutes
            timeout: 180000,
          })
          .pipe(
            map((response: XMLHttpRequest) => {
              if (typeof response === 'string') {
                return JSON.parse(response);
              }
              return response;
            }),
            tap((response: XMLHttpRequest) => {
              if (response.status !== 200) {
                // window.location.replace(`${errURL || '/error.html'}?error=${response.response}`);
                const result = { ...data, status: 'Error', [ajax.label]: response.response };
                updateData(result);
                failed(response.response);
              } else {
                const result = { ...data, status: 'Success', [ajax.label]: response.response };
                updateData(result);
                success(result);
              }
            }),
          );
        return obRx$;
    };

  useEffect(() => {
      const ajaxRX: Subscription = onAjaxPost(ajax, loading, success, failed).subscribe();
      return ()=> {
        ajaxRX.unsubscribe();
      }
  }, []);
  return [data, onAjaxPost];
};
