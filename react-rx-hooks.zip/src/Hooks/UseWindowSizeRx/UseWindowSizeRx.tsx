import { useState, useEffect, PropsWithChildren, Dispatch, SetStateAction } from 'react';
import { interval, fromEvent, Observable, Subscription } from 'rxjs';
import { debounce } from 'rxjs/operators';

type UseWindowSizeDebouncedReturn = { width: number | undefined; height: number | undefined; };

type UseWindowSizeDebounced = (element: PropsWithChildren<HTMLElement>) => UseWindowSizeDebouncedReturn;

/**
 * Debounce the current window size using use-debounce library
 *
 * @param {HTMLElement} element The HTMLElement for `useWindowSizeDebounced` to fetch element width and height.
 * @returns {object} Window Size based on mediaQuery
 * @export
 */

export const useWindowSizeDebounced: UseWindowSizeDebounced = (element: PropsWithChildren<HTMLElement>) => {
  const isClient: boolean = typeof window === 'object';
  const getSize: () => UseWindowSizeDebouncedReturn = () => {
    const Size = {
      width: isClient ? (element ? element.clientWidth : document.body.clientWidth) : undefined,
      height: isClient ? (element ? element.clientHeight : document.body.clientHeight) : undefined,
    };
    return Size;
  };
  const [windowSize, setWindowSize]: [UseWindowSizeDebouncedReturn, Dispatch<SetStateAction<UseWindowSizeDebouncedReturn>>] = useState(getSize);
  const handleResize = () => {
    setWindowSize(getSize);
  };
  const rxResize$: Observable<Event> = fromEvent(window, 'resize').pipe(debounce(() => interval(1000)));
  useEffect(() => {
    const subscription: Subscription = rxResize$.subscribe((x) => handleResize());
    return () => subscription.unsubscribe();
  },[]);

  return windowSize;
};
